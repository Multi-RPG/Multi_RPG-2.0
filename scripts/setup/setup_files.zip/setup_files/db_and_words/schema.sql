CREATE TABLE Users (
user_id varchar(255) NOT NULL PRIMARY KEY,
level int,
money int
, peace int, peace_cd int);
CREATE TABLE Lottery(
ticket_id varchar(255) NOT NULL PRIMARY KEY,
ticket_guess int,
ticket_active int,
CONSTRAINT fk_users2
FOREIGN KEY (ticket_id)
REFERENCES Users(user_id)
ON UPDATE CASCADE
ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS "Shop" (
	"item_id"	INTEGER PRIMARY KEY AUTOINCREMENT,
	"name"	TEXT,
	"type"	TEXT,
	"level"	INTEGER,
	"price"	INTEGER
);
CREATE TABLE IF NOT EXISTS "Battles" (
	"fighter_id"	varchar(255) NOT NULL,
	"tourney_server_id"	varchar(255) NOT NULL DEFAULT 0,
	"weapon_level"	int DEFAULT 0,
	"helmet_level"	int DEFAULT 0,
	"chest_level"	int DEFAULT 0,
	"boots_level"	int DEFAULT 0,
	"battles_lost"	int,
	"battles_won"	int,
	"total_winnings"	int,
	PRIMARY KEY("fighter_id"),
	CONSTRAINT "fk_users" FOREIGN KEY("fighter_id") REFERENCES "Users"("user_id") ON UPDATE CASCADE ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS "Servers" (
"server_id"varchar(255) NOT NULL,
"announcements"int,
PRIMARY KEY("server_id")
);
CREATE TABLE IF NOT EXISTS "Pets" (
"pet_id"varchar(255) NOT NULL,
        "pet_name"  varchar(255),
"pet_xp"INTEGER,
"pet_level"INTEGER,
PRIMARY KEY("pet_id"),
FOREIGN KEY("pet_id") REFERENCES "Users"("user_id") ON UPDATE CASCADE ON DELETE CASCADE
);
